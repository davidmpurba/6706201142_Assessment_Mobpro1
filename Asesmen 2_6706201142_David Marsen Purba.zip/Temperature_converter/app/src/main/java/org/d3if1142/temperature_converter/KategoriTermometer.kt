package org.d3if1142.temperature_converter

enum class KategoriTermometer {
    CELCIUS, FAHRENHEIT, KELVIN
    
}