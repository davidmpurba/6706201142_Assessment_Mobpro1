package org.d3if1142.temperature_converter.model

data class HasilConvert(

    val hasilCelcius: Float,
    val hasilFahrenheit: Float,
    val hasilKelvin: Float,
    var selectedId: Int

)
