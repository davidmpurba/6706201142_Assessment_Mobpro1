package org.d3if1142.temperature_converter.ui

import androidx.fragment.app.Fragment
import org.d3if1142.temperature_converter.R
import org.d3if1142.temperature_converter.databinding.FragmentAboutBinding

class AboutFragment: Fragment(R.layout.fragment_about)